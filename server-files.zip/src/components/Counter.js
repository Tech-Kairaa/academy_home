// import CountUp from "react-countup";
// import ReactVisibilitySensor from "react-visibility-sensor";
// const Counter = ({ end, decimals }) => {
//   return (
//     <CountUp
//       end={end ? end : 100}
//       duration={3}
//       decimals={decimals ? decimals : 0}
//     >
//       {({ countUpRef, start }) => (
//         <ReactVisibilitySensor onChange={start} delayedCall>
//           <t data-from="0" data-to={end} ref={countUpRef}>
//             count
//           </t>
//         </ReactVisibilitySensor>
//       )}
//     </CountUp>
//   );
// };

// export default Counter;

import React from 'react';

const Counter = () => {
	return <div>Counter section</div>;
};

export default Counter;
