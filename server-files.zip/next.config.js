module.exports = {
	reactStrictMode: true,
	swcMinify: true,
	pageExtensions: ['jsx', 'js', 'tsx', 'ts'],
	distDir: 'build',
};
